<?php

use Illuminate\Support\Facades\Route;


use App\Http\Controllers\frontend\HomeController;
use App\Http\Controllers\frontend\Food_helpController;
use App\Http\Controllers\frontend\ViewController;
use App\Http\Controllers\frontend\Mahana_kifalatController;
use App\Http\Controllers\frontend\QurbaniController;

Route::get('/',[HomeController::class,'index']);
Route::get('/food_help',[Food_helpController::class,'index']);
Route::get('/view_details',[ViewController::class,'index']);
Route::get('/mahana_kifalat',[Mahana_kifalatController::class,'index']);
Route::get('/qurbani',[QurbaniController::class,'index']);
