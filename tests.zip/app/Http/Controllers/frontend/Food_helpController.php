<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Food_helpController extends Controller
{
    public function index()
    {
        return view("frontend.food_help");
    }
}
