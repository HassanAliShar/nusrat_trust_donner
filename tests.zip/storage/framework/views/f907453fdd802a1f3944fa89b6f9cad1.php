<script type="text/javascript" src="<?php echo e(url('frontend/js/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/popper.js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/pages/widget/excanvas.js')); ?>"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- waves js -->
    <script src="<?php echo e(url('frontend/pages/waves/js/waves.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/modernizr/modernizr.js')); ?>"></script>
    <!-- slimscroll js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <!-- Chart js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/chart.js/Chart.js')); ?>"></script>
    <!-- amchart js -->
    <script src="https://www.amcharts.com/lib/3/amcharts.js')}}"></script>
    <script src="<?php echo e(url('frontend/pages/widget/amchart/gauge.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/pages/widget/amchart/serial.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/pages/widget/amchart/light.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/pages/widget/amchart/pie.min.js')); ?>"></script>

    <!-- menu js -->
    <script src="<?php echo e(url('frontend/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/vertical-layout.min.js')); ?>"></script>
    <!-- custom js -->
    <script  src="<?php echo e(url('frontend/pages/dashboard/custom-dashboard.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('frontend/js/script.js')); ?>" type="text/javascript" ></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\nusrat\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>